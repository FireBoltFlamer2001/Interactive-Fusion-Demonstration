# Read Me

## The folloing information cantains alot about the game, legals and instalation guid!

**How To Install**

- You will need:
1. 2MB of free disk space
2. Java script enabled on your browser

- To play the game you will need:
1. Run the Interactive Fusion Demonstration.html

- You can bookmark the game in your browser for fast access if you want to

**A Note From The Dev**
- "I made this game for a class project, it was about "Renewable Energy"" -SalmonCannon263

**Credits**

- All elements of the Game were created by me(SalmonCannon263) and are considered intellectual property and/or properties exclusively owned by me(SalmonCannon263). I(SalmonCannon263) retain all rights to the aforementioned intellectual property or properties, excluding those specifically listed above.

**Questons**

If you have any questions or concerns about these the game, please contact me(SalmonCannon263) at lolcatlolcat78@gmail.com.

**Attribution**

- If you wish to distribute modified work, you must properly attribute the original creator and provide appropriate credit(s).

- To attribute the Game, you must include the following notice in a prominent location in the documentation or accompanying materials and/or:

- Original Game created by SalmonCannon263. All elements considered intellectual property exclusively owned by SalmonCannon263.

- Please note that you may not modify and/or remove the "opening_page.html" and "Read Me.md" files/documents as they contain important information regarding the Game and its use. However, you may add your own credits to the "Read Me.md" file, provided that they are placed in between the following markers:

--- Modifier's Credits ---
[Your credits here]
--- Modifier's Credits End ---

- Please en or the original Game.

**Modifer's Attribution**

--- Modifier's Credits ---
[Your credits here]
--- Modifier's Credits End ---

**Terms of Service**

- Welcome to The Interactive Fusion Demonstration ("the Game"). These terms and conditions ("Terms") govern your
 use of the Game, so please read them carefully before playing.

- By playing the Game, you agree to be bound by these Terms. If you do not agree to these Terms, you may not play the Game.

- Use of the Game
You may use the Game only for lawful purposes and in accordance with these Terms. You are responsible for ensuring that your use of the Game complies with all applicable laws and regulations.

- Intellectual Property Rights
I own all intellectual property rights in/to the Game, including but not limited to copyrights, trademarks, and trade secrets. I grant you a non-exclusive, revocable license to use, distribute if modified, and modify the Game, provided that you attribute me(SalmonCannon263) as the original creators and do not use the Game for commercial purposes, whether modified or not.

- You represent and warrant that you have all necessary rights and permissions to upload or submit User Content and that your User Content does not infringe or misappropriate any intellectual property rights, privacy rights, or other rights of any third party.

- Indemnification
You agree to indemnify and hold me(SalmonCannon263) harmless from any claims, damages, expenses, or other losses arising out of your use of the Game or your violation of these Terms.

- Limitation of Liability
To the maximum extent permitted by law, I am not liable for any direct, indirect, incidental, consequential, or special damages arising out of or in connection with your use of the Game, whether based on contract, tort, strict liability, or any other legal theory.

- Changes to the Terms
I may update or modify these Terms at any time, without notice to you. Your continued use of the Game after any such changes constitutes your acceptance of the new Terms.

- Governing Law
These Terms are governed by and construed in accordance with the laws of [Your Jurisdiction], without giving effect to any principles of conflicts of law.

- Entire Agreement
These Terms constitute the entire agreement between you and me(SalmonCannon263) with respect to the Game and supersede all prior or contemporaneous communications and proposals, whether oral or written or typed, between you and me(SalmonCannon263).

If you have any questions or concerns about these Terms, please contact me(SalmonCannon263) at lolcatlolcat78@gmail.com.